---
title: "My First Blog Post"
pubDate: 2025-09-29
description: "This is the first post on my new blog."
author: "SnakeDoc"
image:
    url: "https://docs.astro.build/assets/rose.webp"
    alt: "The Astro logo on a dark background."
tags: ["astro", "blog", "frontend", "web", "banana"]
---
Welcome to my _new blog_ about lerning Astro! Here i will share my progress building my blog.

## What I've Accomplished

1. **Installing Astro**: First, installed Node.js and then created a new Astro project and connected it to Github & Netlify.

2. **Making Pages**: I then learnt how to make pages by creating new `.astro` files and placing them in the `src/pages` folder.

3. **Making Blog Posts**: This is my first blog post made using a Markdown file.

## What's Next?

I will finish the tutorial and keep adding more posts.

