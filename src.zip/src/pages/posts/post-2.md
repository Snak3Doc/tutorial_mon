---
layout: ../../layouts/MarkdownPostLayout.astro
title: "My Second Blog Post"
pubDate: 29-09-2025
description: "This is the second post on my new blog."
author: "SnakeDoc"
image:
    url: "https://docs.astro.build/assets/rose.webp"
    alt: "The Astro logo on a dark background."
tags: ["astro", "blog", "frontend", "web"]
---
# Lorem Ipsum Is Cool

Aliquam lobortis metus eros, id fermentum nisl sagittis eu. Aenean egestas dictum mi eget tincidunt. Fusce tincidunt gravida congue. Fusce pulvinar, turpis ut vulputate tempus, turpis arcu dignissim libero, at scelerisque ipsum dui nec ex. Donec pulvinar aliquam lacinia. Donec id tellus nunc. Maecenas et ornare mauris. Donec volutpat erat nec porta commodo. Proin bibendum enim sed lacinia suscipit. Morbi suscipit in sapien eget pretium. Etiam tincidunt vel odio quis ullamcorper.