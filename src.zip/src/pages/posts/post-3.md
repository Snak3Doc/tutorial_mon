---
layout: ../../layouts/MarkdownPostLayout.astro
title: "My Third Blog Post"
pubDate: 29-09-2025
description: "This is the third post on my new blog."
author: "SnakeDoc"
image:
    url: "https://docs.astro.build/assets/rose.webp"
    alt: "The Astro logo on a dark background."
tags: ["astro", "blog", "frontend", "web"]
---
# Lorem Ipsum Is Bad?

Integer vitae urna lectus. Aenean vitae accumsan turpis, sed varius nunc. Nulla eleifend metus quis mauris pulvinar convallis. Mauris ultricies vehicula mauris ac aliquam. Etiam aliquet magna et arcu elementum, eget commodo elit facilisis. Phasellus non metus a nisl molestie gravida. Aliquam quis mollis nisl, ac vulputate tortor. Morbi id nisi sed elit lobortis tempus non nec dui. Sed tristique mauris facilisis consectetur maximus. Nunc feugiat mauris mi, vel semper risus pellentesque eu. Mauris elit est, malesuada id placerat id, vehicula vitae nibh. Vivamus auctor diam ac nunc imperdiet, sit amet bibendum dolor ultricies.